<p>Customer ID: <?=$customerId?></p>
<p>Name: <?=$customerName?></p>
<p>Email: <?=$customerEmail?></p>
<p>Primary Contact: <?= $primaryContact?></p>
<p>Secondary Contact: <?= $secondaryContact?></p>
<p>Location: <?= $location;?></p>
<p>FRN Code: <?= $frnCode;?></p>