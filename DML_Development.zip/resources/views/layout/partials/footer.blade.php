</div>
<!-- /.content-wrapper -->
<!-- FOOTER -->
<footer class="footer text-center clearfix"><?php echo date('Y'); ?> © Diamond Mela Jewels Ltd. All Rights Reserved.
</footer>
</div>
<!--/ #wrapper -->