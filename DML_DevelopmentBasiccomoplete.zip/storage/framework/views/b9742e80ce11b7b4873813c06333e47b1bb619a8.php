<footer class="col-sm-12 text-center">
	<?php if(\Request::is('register')): ?>
	  <hr>
	  	<p>Already have an account? <a href="<?=URL::to('/');?>/login" class="text-primary m-l-5"><b>Log In</b></a>
	  </p>
	<?php endif; ?>
</footer><?php /**PATH E:\xampp\htdocs\DML_Development\resources\views/layout/registrationpartials/footer.blade.php ENDPATH**/ ?>