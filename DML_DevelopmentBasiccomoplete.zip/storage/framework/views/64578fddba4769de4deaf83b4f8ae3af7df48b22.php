<div id="wrapper" class="row wrapper">
    <div class="col-10 ml-sm-auto col-sm-8 col-md-4 ml-md-auto login-center mx-auto">
            <div class="navbar-header text-center">
                <a href="<?=URL::to('/');?>">
                    <img alt="sddf" src="http://203.112.144.109/dmlsoftware/public/assets/demo/logo-expand-dark.png">
                </a>
            </div><?php /**PATH E:\xampp\htdocs\DML_Development\resources\views/layout/registrationpartials/nav.blade.php ENDPATH**/ ?>