</div>
<!-- /.content-wrapper -->
<!-- FOOTER -->
<footer class="footer text-center clearfix"><?php echo date('Y'); ?> © Diamond Mela Jewels Ltd. All Rights Reserved.
</footer>
</div>
<!--/ #wrapper --><?php /**PATH E:\xampp\htdocs\DML_Development\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>