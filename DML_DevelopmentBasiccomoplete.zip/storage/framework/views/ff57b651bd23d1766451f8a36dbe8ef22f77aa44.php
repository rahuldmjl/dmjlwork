<!DOCTYPE html>

<html lang="en">

 <head>

   <?php echo $__env->make('layout.registrationpartials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 </head>

 <body class="body-bg-full profile-page" style="background-image: url(<?=URL::to('/');?>/assets/demo/night.jpg)">


<?php echo $__env->make('layout.registrationpartials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout.registrationpartials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layout.registrationpartials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layout.registrationpartials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 </body>

</html><?php /**PATH E:\xampp\htdocs\DML_Development\resources\views/layout/registrationlayout.blade.php ENDPATH**/ ?>