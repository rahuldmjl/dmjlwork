<!-- Scripts -->
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.2/umd/popper.min.js"></script>
    <script src="<?=URL::to('/');?>/assets/js/bootstrap.min.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/magnific-popup.js/1.1.0/jquery.magnific-popup.min.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/mediaelement/4.1.3/mediaelementplayer.min.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/metisMenu/2.7.0/metisMenu.min.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/jquery.perfect-scrollbar/0.7.0/js/perfect-scrollbar.jquery.js"></script>
    <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.29.2/sweetalert2.all.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
     <script src="<?=URL::to('/');?>/js/common.js"></script>
    <?php echo $__env->yieldContent('distinct_footer_script'); ?>
     
    <script src="<?=URL::to('/');?>/assets/js/theme.js"></script>
    <script src="<?=URL::to('/');?>/assets/js/custom.js"></script>

    <!-- <script src="<?=URL::to('/');?>/cdnjs.cloudflare.com/ajax/libs/datatables/1.10.15/js/dataTables.responsive.min.js"></script> -->
</body>


<!-- Mirrored from oscar.dharansh.in/default/ by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 28 Apr 2019 12:17:49 GMT -->
</html><?php /**PATH E:\xampp\htdocs\DML_Development\resources\views/layout/partials/footer-scripts.blade.php ENDPATH**/ ?>