<?php
namespace App;
use Illuminate\Database\Eloquent\Model;
class CatalogCategoryEntity extends Model {
	
	protected $guarded = [];
	protected $table = 'catalog_category_entity';
}
?>