<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Productupload extends Model
{
    //
    protected $guarded = [];
    protected $table = 'products';
}
