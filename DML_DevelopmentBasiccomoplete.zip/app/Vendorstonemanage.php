<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vendorstonemanage extends Model
{
    protected $guarded = [];
    public $table = "vendorstonemanages";
    protected $primaryKey = 'id';
}