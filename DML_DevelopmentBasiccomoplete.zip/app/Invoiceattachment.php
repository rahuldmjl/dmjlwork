<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Invoiceattachment extends Model
{
    //
	protected $guarded = [];
    protected $table = 'invoice_attachment';
}
