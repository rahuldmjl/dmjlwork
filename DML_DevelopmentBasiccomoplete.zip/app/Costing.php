<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Costing extends Model
{
    //
    protected $guarded = [];
    protected $table = 'costings';

}
