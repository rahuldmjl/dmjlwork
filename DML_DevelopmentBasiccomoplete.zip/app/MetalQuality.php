<?php 
namespace App;
use Illuminate\Database\Eloquent\Model;

class MetalQuality extends Model {

	protected $guarded = [];
    protected $table = 'grp_metal_quality';
}
?>