<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Costingdata extends Model
{
    //
    protected $guarded = [];
}
