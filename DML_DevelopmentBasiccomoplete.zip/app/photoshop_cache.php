<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class photoshop_cache extends Model
{
    

    
}
