<?php 
namespace App;
use Illuminate\Database\Eloquent\Model;

class CatalogCategoryEntityVarchar extends Model {

	protected $guarded = [];
    protected $table = 'catalog_category_entity_varchar';
}
?>