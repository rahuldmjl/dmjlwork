<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost/',
    'get_country_list' => NULL,
    'get_states_list' => NULL,
    'create_customer' => NULL,
    'website_url_for_gst_pan_attachment' => NULL,
    'generate_invoice' => NULL,
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:vDw9rq9wWd31zD8YrUWoZXNAJU/fupaT5OUA92VcZME=',
    'cipher' => 'AES-256-CBC',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Barryvdh\\DomPDF\\ServiceProvider',
      23 => 'DougSisk\\CountryState\\CountryStateServiceProvider',
      24 => 'ConsoleTVs\\Charts\\ChartsServiceProvider',
      25 => 'Intervention\\Image\\ImageServiceProvider',
      26 => 'App\\Providers\\AppServiceProvider',
      27 => 'App\\Providers\\AuthServiceProvider',
      28 => 'App\\Providers\\EventServiceProvider',
      29 => 'App\\Providers\\RouteServiceProvider',
      30 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
      31 => 'Barryvdh\\DomPDF\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
      'Dompdf' => 'Dompdf\\Dompdf',
      'CommonHelper' => 'App\\Helpers\\CommonHelper',
      'DiamondHelper' => 'App\\Helpers\\DiamondHelper',
      'Charts' => 'ConsoleTVs\\Charts\\Facades\\Charts',
      'Image' => 'Intervention\\Image\\Facades\\Image',
      'PhotoshopHelper' => 'App\\Helpers\\PhotoshopHelper',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'token',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'breadcrumbs' => 
  array (
    'view' => 'breadcrumbs::bootstrap4',
    'files' => 'E:\\xampp\\htdocs\\DML_Development\\routes/breadcrumbs.php',
    'unnamed-route-exception' => true,
    'missing-route-bound-breadcrumb-exception' => true,
    'invalid-named-breadcrumb-exception' => true,
    'manager-class' => 'DaveJamesMiller\\Breadcrumbs\\BreadcrumbsManager',
    'generator-class' => 'DaveJamesMiller\\Breadcrumbs\\BreadcrumbsGenerator',
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'encrypted' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
      ),
    ),
    'prefix' => 'laravel_cache',
  ),
  'constants' => 
  array (
    'dir' => 
    array (
      'purchased_invoices' => 'uploads/docs/purchased_invoices/',
      'issue_vaucher' => 'uploads/issuevaucher/',
      'diamond_invoice' => 'uploads/diamondinvoice/',
      'invoice_attachment' => 'uploads/paymentinvoice',
      'paid_invoice_attachment' => 'uploads/paid_invoice',
      'return_to_vendor_voucher' => 'uploads/return_to_vendor_receipts/',
      'diamond_invoice_attachment' => 'uploads/invoice_attachment',
      'product_list_img' => '/html/DML-Internal-Software-2.0/public/',
      'product_list_img_def' => '/html/DML-Internal-Software-2.0/public/img/',
      'website_url_for_product_image' => 'http://203.112.144.7/media/catalog/product/',
      'website_url_for_product_image_curl' => 'http://10.22.40.7/media/catalog/product/',
      'return_to_vendor_receipts' => 'uploads/return_to_vendor_receipts/',
      'qrcode_images' => 'img/product_qrcodes/',
      'product_image_path' => 'uploads/img',
    ),
    'Discount_type' => 
    array (
      'approval_less25' => 'discount_approval_less_25',
      'approval_25tolakhs' => 'discount_approval_25_to_lakhs',
      'approval_abovelakhs' => 'discount_approval_above_lakhs',
      'deposit_less25' => 'discount_deposit_less_25',
      'deposit_25tolakhs' => 'discount_deposit_25_to_lakhs',
      'deposit_abovelakhs' => 'discount_deposit_above_lakhs',
      'invoice_less25' => 'discount_invoice_less_25',
      'invoice_25tolakhs' => 'discount_invoice_25_to_lakhs',
      'invoice_abovelakhs' => 'discount_invoice_above_lakhs',
      'approval_less25_18K' => 'discount_approval_less_25_18k',
      'approval_25tolakhs_18K' => 'discount_approval_25_100k_18k',
      'approval_abovelakhs_18K' => 'discount_approval_gt_100k_18k',
      'deposit_less25_18K' => 'discount_deposit_less_25_18k',
      'deposit_25tolakhs_18K' => 'discount_deposit_25_100k_18k',
      'deposit_abovelakhs_18K' => 'discount_deposit_gt_100k_18k',
      'invoice_less25_18K' => 'discount_invoice_less_25_18k',
      'invoice_25tolakhs_18K' => 'discount_invoice_25_100k_18k',
      'invoice_abovelakhs_18K' => 'discount_invoice_gt_100k_18k',
    ),
    'Metal_Quality' => 
    array (
      '14K Yellow Gold' => '14K Yellow Gold',
      '14K White Gold' => '14K White Gold',
      '14K Rose Gold' => '14K Rose Gold',
      '18K Yellow Gold' => '18K Yellow Gold',
      '18K White Gold' => '18K White Gold',
      '18K Rose Gold' => '18K Rose Gold',
      '18K Two Tone' => '18K Two Tone',
      '14K Two Tone' => '14K Two Tone',
      'Platinum(950)' => 'Platinum(950)',
      '14K Three Tone' => '14K Three Tone',
      '18K Three Tone' => '18K Three Tone',
    ),
    'message' => 
    array (
      'vendor_charges_add_success' => 'Record added successfully',
      'vendor_charges_update_success' => 'Record updated successfully',
      'vendor_metal_rates_add_success' => 'Record added successfully',
      'vendor_metal_rates_update_success' => 'Record updated successfully',
      'vendor_DiamondType_add_success' => 'Diamond Type created successfully',
      'vendor_DiamondType_update_success' => 'Diamond Type updated successfully',
      'vendor_ProductType_add_success' => 'Product Type created successfully',
      'vendor_ProductType_update_success' => 'Product Type updated successfully',
      'vendor_current_password_error' => 'Your current password does not matches with the password you provided. Please try again.',
      'vendor_new_password_error' => 'New Password cannot be same as your current password. Please choose a different password.',
      'vendor_new_password_success' => 'Password changed successfully !',
      'Payment_Type_add_success' => 'Payment Header Created Successfully',
      'Payment_Type_update_success' => 'Payment Header Updated Successfully',
      'Payment_Type_delete_success' => 'Payment Header Deleted Successfully',
      'payment_adv_payment_created_successfully' => 'Advance payment created successfully',
      'payment_customer_not_selected' => 'Please select customer',
      'payment_customer_remark_required' => 'Remarks is required',
      'Payment_add_success' => 'Payment created successfully',
      'Payment_update_success' => 'Payment updated successfully',
      'Payment_Approved_success ' => 'Payment Approved successfully',
      'Payment_Decline_success ' => 'Payment Decline successfully',
      'Allredy_Approved ' => 'This Transaction Allredy Approved',
      'Allredy_Decline' => 'This Transaction Allredy Decline',
      'Payment_delete_success ' => 'Payment Information deleted successfully',
      'settings_saved' => 'Settings Saved',
      'settings_error' => 'Issue Voucher No is already is exist , Please change the series or prefix from Settings',
      'order_placed' => 'Order Placed Successfully',
      'labour_charge_not_added' => 'Labour charges not added in the system',
      'certificate_exsist' => ' Certificate(s)  already exists',
      'import_success' => 'Import successfully',
      'qc_status_approved' => 'Product(s) has been accepted successfully',
      'qc_status_rejected' => 'Product(s) has been rejected successfully',
      'IGI_added_success' => 'IGI has been added successfully',
      'request_invoice_success' => 'Requested invoice successfully',
      'return_memo_success' => 'Returned memo successfully',
      'item_exsist' => ' Item(s)  already exists',
      'igied_already' => ' certificate(s) already igied',
      'igi_rejected_success' => 'IGI Rejected Successfully',
      'update_products_success' => 'Product(s) has been Updated successfully',
      'update_products_failure' => 'Product(s) has been not Updated successfully',
      'delete_products_success' => 'Product(s) has been Deleted successfully',
      'delete_products_failure' => 'Product(s) has been not Deleted successfully',
      'Diamond_Transaction_add_success' => 'Diamond Transaction Add Successfully',
      'Diamond_weight_update_success' => 'Diamond Weight Updated Successfully',
      'Diamond_Transaction_update_success' => 'Diamond Transaction Updated Successfully',
      'Diamond_invoiceattachment_add_success' => 'Diamond invoice attchment added successfully',
      'diamond_issue_added_success' => 'Diamond Issued Successfully',
      'diamond_issue_updated_success' => 'Diamond Updated successfully',
      'Diamond_combination_repeat' => 'Diamond combination repeat',
      'Diamond_date_check' => 'Due date should be grater',
      'Diamond_vendor_exist' => 'Vendor id does not exists in database',
      'Diamond_packet_exist' => 'Packet id does not exists in database',
      'DiamondRaw_Add' => 'Raw Diamond Created successfully ',
      'DiamondRaw_CVD' => 'Raw Diamond CVD Transaction  successfully ',
      'DiamondRaw_Assorted' => 'Raw Diamond Assorted Transaction  successfully ',
      'DiamondRaw_Sizing' => 'Raw Diamond Sizing Transaction  successfully ',
      'Diamond_weight_mismatch' => 'Total weight is mismatch',
      'exceeded_loss_limit' => 'You have Exceeded Loss Limit !',
      'Diamond_Inventory_upload_file' => 'Please upload Excel file',
      'Diamond_Inventory_upload_invalid_file' => 'Please upload a valid xls/xlsx file..!!',
      'Metal_add_transaction' => 'Metal transaction added successfully',
      'issue_transaction' => 'Metal issued successfully',
      'metal_weight' => 'You cant issue , because selected metal weight is not available in inventory',
      'metal_cant_issue' => 'You cant issue , because selected metal type is not available in inventory',
      'diamond_cant_issue' => 'You cant issue , because selected Diamond type is not available in inventory',
      'reset_link_success' => 'we have e-mailed your password reset link !!',
      'inventory_frncode_already_exist' => 'FRN Code already exist',
      'inventory_new_invoice_created' => 'New invoice created',
      'inventory_bulk_upload_invalid_file' => 'Please upload CSV file',
      'product_image_download_limit' => 'Product limit is upto 500 only for Generate PDF',
      'inventory_status_changed' => 'Inventory status changed successfully',
      'inventory_default_failure_message' => 'Something went wrong! Please try again',
      'inventory_status_not_changed' => 'Something went wrong! Please try again',
      'inventory_status_product_not_selected' => 'Please select product',
      'inventory_generate_approval_confirmation' => 'Are you sure to generate approval?',
      'inventory_cancel_approval_confirmation' => 'Are you sure to cancel approval?',
      'inventory_deliver_approval_confirmation' => 'Are you sure to deliver approval?',
      'inventory_approval_cancellation_success_message' => 'Approval cancelled successfully',
      'inventory_approval_delivery_success_message' => 'Approval delivered successfully',
      'inventory_approval_number_not_generated' => 'Approval number not generated for this Certificate(s): ',
      'inventory_approval_number_not_generated_for_memo' => 'Approval number not generated for this approval',
      'inventory_approval_number_already_generated' => 'Approval number already generated',
      'inventory_approval_number_already_cancelled' => 'Approval number already cancelled',
      'inventory_export_excel_product_not_selected' => 'Please select product',
      'inventory_export_pdf_product_not_selected' => 'Please select checkbox',
      'inventory_generate_memo_product_not_selected' => 'Please select product!',
      'inventory_generate_invoicememo_approval_not_selected' => 'Please select approval memo!',
      'inventory_export_csv_product_not_selected' => 'Are you sure to download csv for all products?',
      'inventory_approval_generated_success_message' => 'Approval generated successfully',
      'inventory_generate_invoicememo_product_not_selected' => 'Please select product!',
      'inventory_generate_invoicememo_customer_not_exist' => 'Customer is not available',
      'invoice_already_generated' => 'Invoice already generated for Certificate(s): ',
      'invoice_number_already_generated' => 'Invoice already generated for this invoice number',
      'invoice_already_generated_for_approval' => 'Invoice already generated for Approval(s): ',
      'return_memo_already_generated_for_approval' => 'Return memo already generated for Approval(s): ',
      'return_memo_already_generated_for_products' => 'Return memo already generated for Certificate(s): ',
      'memo_already_generated' => 'Memo already generated for Certificate(s): ',
      'inventory_quotation_product_not_selected' => 'Plese select product',
      'inventory_quotation_generate_success_message' => 'Quotation generated successfully',
      'inventory_quotation_update_success_message' => 'Quotation updated successfully',
      'inventory_quotation_delete_success_message' => 'Quotation deleted successfully',
      'inventory_quotation_save_failure_message' => 'Something went wrong! Please try again later!',
      'sales_credit_note_generate_confirmation' => 'Are you sure to generate credit note?',
      'inventory_delete_quotation_confirmation' => 'Are you sure to delete quotation?',
      'qrcode_generated' => 'Qrcode generated successfully',
      'qrcode_not_generated' => 'Qrcode not generated',
      'inventory_certificate_added' => 'added successfully',
      'inventory_certificate_not_deleted' => 'Certificate(s) not removed successfully',
      'inventory_certificate_deleted' => 'Certificate(s) removed successfully',
      'inventory_certificate_doesnt_exist' => 'This certificate doesn\'t exist',
      'inventory_certificate_not_found' => 'Certificate not available',
      'inventory_certificate_already_exist' => 'This certificate are already exist',
      'inventory_generate_invoicememo_csv_not_selected' => 'Please upload CSV',
      'inventory_generate_returnmemo_confirmation' => 'Are you sure to generate return memo ?',
      'inventory_memo_generated_success' => 'Memo generated successfully',
      'inventory_memo_generated_failure' => 'Something went wrong! Please try again later!',
      'inventory_product_moved_to_showroom_success' => 'Product moved to inventory successfully',
      'inventory_memo_not_generated' => 'Approval not generated for this Certificate(s): ',
      'invoice_remove_memo_product_confirmation' => 'Are you sure to remove this product?',
      'inventory_return_memo_generated_success' => 'Return memo generated successfully',
      'inventory_product_removed_from_memo' => 'Product removed successfully',
      'invoice_cancellation_success' => 'Invoice canceled successfully!',
      'invoice_updated_successfully' => 'Invoice updated successfully',
      'invoice_cancellation_failure' => 'Something went wrong! Please try again!',
      'invoice_cancellation_already_done' => 'Invoice already cancelled for this Certificate(s): ',
      'invoice_created' => 'New invoice has been created.',
      'invoice_updated' => 'Invoice has been updated.',
      'invoice_address_updated' => 'Invoice address has been updated.',
      'inventory_telephone_already_exist' => 'Contact number already exist',
      'invoice_product_removed' => 'Invoice product has been removed.',
      'invoice_cancelled' => 'Invoice has been cancelled.',
      'inventory_approval_number_already_exist' => 'Approval number already exist',
      'sales_return_already_generated' => 'Sales return already generated for this Certificate(s): ',
      'invoice_cancellation_confirmation' => 'Are you sure to cancel invoice?',
      'exhibition_created_successfully' => 'Exhibition created successfully',
      'exhibition_update_successfully' => 'Exhibition updated successfully',
      'exhibition_product_moved_to_showroom_success' => 'Product moved to showroom successfully',
      'invoice_header_title' => 'DIAMOND MELA JEWELS LTD',
      'invoice_regid' => '2307 PANCHRATNA BUILDING OPERA HOUSE,MUMBAI-400004.',
      'invoice_email' => 'account@diamondmela.com',
      'invoice_telephone' => '18002100888/022-49664966',
      'invoice_web_info' => 
      array (
        'text' => 'www.diamondmela.com',
        'url' => 'http://www.diamondmela.com',
      ),
      'returnmemo_company_name' => 'DIAMOND MELA JEWELS LTD',
      'returnmemo_address' => '2307 ,23rD FLOOR, PANCHRATNA BLDG,CHARNI ROAD EAST',
      'returnmemo_city' => 'MUMBAI',
      'returnmemo_pincode' => '400004',
      'returnmemo_state' => 'MAHARASHTRA',
      'returnmemo_pan' => 'ARFCO1133A',
      'returnmemo_contactno' => '022 49664966, 49794979',
      'returnmemo_gstin' => '27AAFCD2233A1ZB',
      'returnmemo_hsn_code' => '71131930',
      'customer_created_successfully' => 'Customer created successfully',
      'customer_primary_contact_already_exist' => 'Primary contact already exist',
      'customer_secondary_contact_already_exist' => 'Secondary contact already exist',
      'customer_payment_created_successfully' => 'Payment created successfully',
      'customer_approval_products_not_available' => 'No approval products available',
      'customer_approval_memo_not_available' => 'No approval memo available',
      'customer_invoice_not_available' => 'No invoices available',
      'costing_not_available' => 'No Costing Data Available',
      'customer_inventory_product_not_available' => 'No inventory product available',
      'customer_address_updated_success' => 'Customer address updated successfully',
      'customer_gstin_updated_success' => 'GSTIN updated successfully',
      'customer_pancard_updated_success' => 'PAN Card updated successfully',
      'customer_personalinfo_updated_success' => 'Personal information updated successfully',
      'customer_pricemarkup_range_error' => 'Please enter a value less than or equal to 100.',
      'customer_pricemarkup_saved_success' => 'Price markup updated successfully',
      'customer_pricemarkup_number_validation_error' => 'Price markup value should be numeric',
      'customer_delete_confirmation_message' => 'Are you sure to delete this customer?',
      'customer_delete_success' => 'Customer deleted successfully',
      'customer_delete_failure' => 'Something went wrong! Please tre again later!',
      'quotation_set_default_price_message' => 'Set default quotation with DML price',
      'quotation_bulk_rate_file_not_selected' => 'Please upload CSV file',
      'quotation_not_created_for_customer' => 'Quotation not found for this customer',
      'showroom_status_changed' => 'Order Status Changed Successfully',
      'showroom_status_not_changed' => 'Something went wrong. Order Status Not Changed !',
      'showroom_state_not_selected_for_salesreturn' => 'Please select state',
      'showroom_sales_return_generate_success_message' => 'Sales return generated successfully',
      'showroom_sales_return_generate_failed_message' => 'Something went wrong! Please try again later!',
      'sales_return_dml_address' => '2307, Floor-23 Panchratna, Opera House, Charni Road, Mumbai-400004 Ph: 022-49664999',
      'sales_return_description' => 'Invoice issued under section 31 of the CGST Act, 2017 read with Rule 46 of Central Goods and Services Tax Rules,2017',
      'sales_return_cin' => 'U74999MH2014PLC2603299',
      'sales_return_gstin' => '27AAFCD2233A1ZB',
      'voucher_generated_successfully' => 'Voucher Generated Successfully',
      'Discount_approval' => 'Approval product discount Added successfully.',
      'Discount_deposit' => 'Deposit product discount Added successfully.',
      'Discount_invoice' => 'Invoice discount Added successfully.',
      'diamond_combination_are_repeated' => 'Diamond Combination Are Repeated',
      'Diamond_weight_more' => 'Sorry..!You can\'t issue due to Diamond weight is more than inventory',
      'Diamond_not_exists' => 'Sorry..!Combination of Diamond you don\'t have in your Invetory',
      'issue_voucher_edit_success' => 'Issue Voucher Edited Successfully',
      'issue_voucher_edit_error' => 'Issue Voucher edited Could\'t Be Edited',
      'weight_more' => ' Weight is more than Issue',
      'returned_success' => ' Weight Returned successfully',
      'voucherno_generated_sucess' => 'Issue voucher number generated successfully',
      'voucherno_generated_failed' => 'Issue voucher number not generated',
      'voucherno_confirmation' => 'Are you sure to Generate Voucher no?',
      'handover_confirmation' => 'Are you sure to Handover?',
      'handover_sucess' => 'Handover successfully',
      'handover_failed' => 'Handover failed',
      'delete_confirmation' => 'Are you sure to Delete Voucher?',
      'delete_sucess' => 'Voucher Deleted successfully',
      'delete_failed' => 'Vaoucher not Deleted successfully',
      'delete_product_confirmation' => 'Are you sure to Delete Product?',
      'purchase_history_update' => 'Purchase History updated successfully.',
      'added_vb' => 'Virtual Box Created successfully.',
      'Code_taken' => 'Box Code Already Taken',
      'Price_Taken' => 'Price Already Taken Between...',
      'Price_Greter_than' => 'From Price Already Taken...',
      'Certificate_No_Exist' => 'Following Certificate Already Exist',
      'CSV_Data_Not_Found' => 'Certificate does not belongs to selected price range',
      'CSV_Record_Added' => 'Product Imported',
      'CSV_data_Limit' => 'CSV Data is more then your product limit',
      'Product_Not_Fount' => 'No products moved yet',
      'Product_Cat_Not_Match' => 'Certificate No. Not Match On This Category',
      'VB_Edit' => 'Virtual Box Updated successfully.',
    ),
    'enum' => 
    array (
      'costing_types' => 
      array (
        'RD' => 'RD',
        'ROUND' => 'ROUND',
        'Round' => 'Round',
        'platinum' => 'platinum',
        'platinum(950)' => 'platinum(950)',
        'gold' => 'gold',
        'Y' => 'Y',
        'YELLOW' => 'YELLOW',
        'WHITE' => 'WHITE',
        'W' => 'W',
        'Rose_Gold' => 'Rose Gold',
        'White_Gold' => 'White Gold',
        'Yellow_Gold' => 'Yellow Gold',
        'ROSE' => 'ROSE',
        'PINK' => 'PINK',
        'P' => 'P',
        'R' => 'R',
        'Rose' => 'Rose',
        'Pink' => 'Pink',
        'Yellow' => 'Yellow',
        'White' => 'White',
        'Platinum(950)' => 'Platinum(950)',
        'THREETONE' => 'THREETONE',
        'ThreeTONE' => 'ThreeTONE',
        'TwoTONE' => 'TwoTONE',
        'TWOTONE' => 'TWOTONE',
        'Two_Tone' => 'Two Tone',
        'Three_Tone' => 'Three Tone',
      ),
      'inventory_HSN' => 
      array (
        'diamond_HSN' => '7102',
        'gold_HSN' => '7108',
        'platinum_HSN' => '7110',
        'gemstone_HSN' => '71131940',
        'studed_gold_diamond_HSN' => '71131930',
      ),
      'description_of_voucher' => 
      array (
        'diamond' => 'Cut & Polished Diamonds',
        'gold' => 'Only gold',
        'platinum' => 'Platinum',
      ),
      'gold_units' => 
      array (
        'gold' => 'gms',
      ),
      'diamond_shape' => 
      array (
        'round' => 
        array (
          0 => 'round',
        ),
        'fancy2' => 
        array (
          0 => 'taper',
          1 => 'taper baguette',
          2 => 'baguette',
        ),
        'fancy1' => 
        array (
        ),
      ),
      'metal_type' => 
      array (
        1 => 'Gold',
        2 => 'Silver',
        3 => 'Platinum(950)',
      ),
      'transaction_types' => 
      array (
        'purchase' => 'Purchase',
        'issue' => 'Issue',
        'purchase_from_vendor' => 'Purchase from Vendor',
        'sell' => 'Sell',
        'misc' => 'Misc',
        'return' => 'Return',
      ),
      'customer_view_approval_type' => 
      array (
        'oldest_approval' => 'Oldest Approval',
        'newest_approval' => 'Newest Approval',
        'all_approval' => 'No of Approvals',
      ),
      'cache_expiry_minutes' => '300',
      'qrcode_url' => 'http://diamondmela.com/index.php/qrinsertproduct/index/scancertificate/certificate_no/',
      'stock_type' => 
      array (
        'showroom' => 'Showroom',
        'approval' => 'Approval',
        'pending' => 'Pending',
        'sold' => 'Sold',
      ),
    ),
    'settings' => 
    array (
      'keys' => 
      array (
        'diamond_invoice_number' => 'DIAMOND_INVOICE_NUMBER',
        'showroom_order_number' => 'SHOWROOM_ORDER_NUMBER',
        'pagination' => 'PAGINATION_LIMIT',
        'download_image_limit' => 'PDF_IMAGE_LIMIT',
        'costing_nearby_amount' => 'COSTING_NEARBY_AMOUNT',
        'sales_return_number' => 'SALES_RETURN_NUMBER',
        'return_memo_nub' => 'RETURNED_MEMO_NUMBER',
        'quotation_number' => 'QUOTATION_NUMBER',
        'approval_number' => 'APPROVAL_NUMBER',
        'return_memo_number' => 'RETURN_MEMO_NUMBER',
        'diamond_loss' => 'DIAMOND_LOSS_TOLERENCE_LIMIT',
        'invoice_limit' => 'INVOICE_LIMIT',
        'issue_voucher_prifix' => 'ISSUE_VOUCHER_NO_PREFIX',
        'diamond_issue_voucher_prifix' => 'DIAMOND_ISSUE_VOUCHER_NO_PREFIX',
        'diamond_voucher_series' => 'DIAMOND_VOUCHER_NO_SERIES',
        'gold_voucher_series' => 'GOLD_VOUCHER_NO_SERIES',
        'misc_loss_limit' => 'MISC_LOSS_LIMIT',
        'discount_invoice_less_25' => 'DISCOUNT_INVOICE_LESS_25K_14K',
        'discount_invoice_25_to_lakhs' => 'DISCOUNT_INVOICE_BETWEEN_25K_TO_100K_14K',
        'discount_invoice_above_lakhs' => 'DISCOUNT_INVOICE_ABOVE_100K_14K',
        'discount_invoice_less_25_18k' => 'DISCOUNT_INVOICE_LESS_25K_18K',
        'discount_invoice_25_100k_18k' => 'DISCOUNT_INVOICE_BETWEEN_25K_TO_100K_18K',
        'discount_invoice_gt_100k_18k' => 'DISCOUNT_INVOICE_ABOVE_100K_18K',
        'invoice_increment_id_prefix' => 'INVOICE_INCREMENT_ID_PREFIX',
        'invoice_increment_id' => 'INVOICE_INCREMENT_ID',
        'Delivery_Challan_No' => 'DELIVERY_CHALLAN_NO',
        'igst_percentage' => 'IGST_PERCENTAGE',
        'sgst_percentage' => 'SGST_PERCENTAGE',
        'cgst_percentage' => 'CGST_PERCENTAGE',
        'qc_approval_voucher_no' => 'QC_APPROVAL_VOUCHER_NO',
        'voucher_number' => 'VOUCHER_NUMBER',
      ),
    ),
    'labels' => 
    array (
      'setting_page' => 
      array (
        'diamond_invoice_number' => 'DIAMOND INVOICE NUMBER',
        'general_setting' => 'General Setting',
        'pagination' => 'Default Pagination Limit',
        'download_image_limit' => 'PDF Image Limit',
        'showroom' => 'Showroom',
        'diamond_page' => 'Diamond',
        'order_number' => 'Order Number',
        'sales_return_number' => 'Sales Return Number',
        'rawdiamond' => 'Raw Diamond',
        'return_memo' => 'Return Number',
        'quotation_number' => 'Quotation Number',
        'approval_number' => 'Approval Number',
        'return_memo_number' => 'Return Memo Number',
        'inventory' => 'Inventory',
        'issue_voucher_prifix' => 'Issue Voucher No Prefix',
        'diamond_issue_voucher_prifix' => 'Diamond Issue Voucher No Prefix',
        'diamond_voucher_series' => 'Diamond Voucher No Series',
        'gold_voucher_series' => 'Gold Voucher No Series',
        'misc_loss_limit' => 'Misc Loss Limit',
        'costing' => 'Costing',
        'costing_nearby_amount' => 'Costing Near by Amount',
        'diamond_loss' => 'Diamond Loss',
        'invoice_limit' => 'Invoice Limit',
        'cache' => 'Cache',
        'cache_types' => 'Cache Types',
        'application_cache' => 'Application Cache',
        'config_cache' => 'Config Cache',
        'route_cache' => 'Route Cache',
        'view_cache' => 'View Cache',
        'tmp_var' => 'Tmp Var',
        'discount_invoice_less_25' => 'Discount Invoice Less 25k 14k(%)',
        'discount_invoice_25_to_lakhs' => 'Discount Invoice Between 25k to 100k 14k(%)',
        'discount_invoice_above_lakhs' => 'Discount Invoice Above 100k 14k(%)',
        'discount_invoice_less_25_18k' => 'Discount Invoice Less 25k 18k(%)',
        'discount_invoice_25_100k_18k' => 'Discount Invoice between 25k to 100k 18k(%)',
        'discount_invoice_gt_100k_18k' => 'Discount Invoice Above 100k 18k(%)',
        'invoice_increment_id_prefix' => 'Invoice Increment ID Prefix',
        'invoice_increment_id' => 'Invoice Increment ID',
        'Delivery_Challan_No' => 'Delivery Challan No',
        'backup' => 'DB Backup',
        'db_backup' => 'DB Backup',
        'backup_modules' => 'Backup Modules',
        'igst_percentage' => 'IGST Percentage',
        'sgst_percentage' => 'SGST Percentage',
        'cgst_percentage' => 'CGST Percentage',
        'qc_approval_voucher_no' => 'Approval Voucher No',
        'voucher_number' => 'Voucher Number',
      ),
      'pending' => 'Pending',
      'given_to_vendor' => 'Given to Vendor',
      'in_progress' => 'In Progress',
      'completed' => 'Completed',
    ),
    'apiurl' => 
    array (
      'local' => 
      array (
        'get_metal' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/getmetal/',
        'create_customer' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/registercustomerforinventory/',
        'search_customer' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/searchcustomer/',
        'get_customer' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/getcustomerbyid/',
        'generate_invoice' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/generateinvoice/',
        'generate_seperate_invoice' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/generateseperateinvoice/',
        'generate_memo' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/generatememo/',
        'generate_return_memo' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/generatereturnmemo/',
        'remove_from_order' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/removeproductfromorder/',
        'get_country_list' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/getallcountrylist',
        'get_state_list' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/getallregionlist',
        'remove_memo_product' => 'http://123.108.51.11/index.php/dmlapi/inventory/removememoproduct/',
        'regenerate_memo' => 'http://123.108.51.11/index.php/dmlapi/inventory/regeneratememo',
        'regenerate_invoice' => 'http://123.108.51.11/index.php/dmlapi/inventory/regenerateinvoice',
        'get_country_name' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/getcountryname',
        'remove_invoice_product' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/removeinvoiceproduct/',
        'get_in' => 'In',
        'update_customer_address' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/updatecustomeraddress/',
        'website_url_for_gst_pan_attachment' => 'http://diamondmela.com/upload_customer_doc.php',
        'update_order_address' => 'http://127.0.0.1/dealermela/index.php/dmlapi/inventory/updateorderaddress/',
      ),
      'live' => 
      array (
        'create_customer' => 'http://10.22.40.7/index.php/dmlapi/customers/registercustomerforinventory/',
        'search_customer' => 'http://10.22.40.7/index.php/dmlapi/customers/searchcustomer/',
        'get_customer' => 'http://10.12.40.16/index.php/dmlapi/customers/getcustomerbyid/',
        'generate_invoice' => 'http://10.22.40.7/index.php/dmlapi/inventory/generateinvoice/',
        'generate_seperate_invoice' => 'http://10.22.40.7/index.php/dmlapi/inventory/generateseperateinvoice/',
        'generate_memo' => 'http://10.22.40.7/index.php/dmlapi/inventory/generatememo/',
        'generate_return_memo' => 'http://10.22.40.7/index.php/dmlapi/inventory/generatereturnmemo/',
        'remove_from_order' => 'http://10.22.40.7/index.php/dmlapi/inventory/removeproductfromorder/',
        'get_country_list' => 'http://10.22.40.7/index.php/dmlapi/customers/getallcountrylist',
        'get_state_list' => 'http://10.22.40.7/index.php/dmlapi/customers/getallregionlist',
        'remove_memo_product' => 'http://10.22.40.7/index.php/dmlapi/inventory/removememoproduct/',
        'remove_invoice_product' => 'http://10.22.40.7/index.php/dmlapi/inventory/removeinvoiceproduct/',
        'regenerate_memo' => 'http://10.22.40.7/index.php/dmlapi/inventory/regeneratememo',
        'regenerate_invoice' => 'http://10.22.40.7/index.php/dmlapi/inventory/regenerateinvoice',
        'get_country_name' => 'http://10.22.40.7/index.php/dmlapi/customer/getcountryname',
        'get_in' => ' In',
        'update_customer_address' => 'http://10.22.40.7/index.php/dmlapi/customers/updatecustomeraddress/',
        'website_url_for_gst_pan_attachment' => 'http://diamondmela.com/upload_customer_doc.php',
        'get_metal' => 'http://10.22.40.7/index.php/dmlapi/inventory/getmetal/',
        'update_order_address' => 'http://10.22.40.7/index.php/dmlapi/inventory/updateorderaddress/',
      ),
      'test' => 
      array (
        'get_metal' => 'http://10.12.40.16/index.php/dmlapi/inventory/getmetal/',
        'create_customer' => 'http://10.12.40.16/index.php/dmlapi/customers/registercustomerforinventory/',
        'search_customer' => 'http://10.12.40.16/index.php/dmlapi/customers/searchcustomer/',
        'get_customer' => 'http://10.12.40.16/index.php/dmlapi/customers/getcustomerbyid/',
        'generate_invoice' => 'http://10.12.40.16/index.php/dmlapi/inventory/generateinvoice/',
        'generate_seperate_invoice' => 'http://10.12.40.16/index.php/dmlapi/inventory/generateseperateinvoice/',
        'generate_memo' => 'http://10.12.40.16/index.php/dmlapi/inventory/generatememo/',
        'generate_return_memo' => 'http://10.12.40.16/index.php/dmlapi/inventory/generatereturnmemo/',
        'remove_from_order' => 'http://10.12.40.16/index.php/dmlapi/inventory/removeproductfromorder/',
        'get_country_list' => 'http://10.12.40.16/index.php/dmlapi/customers/getallcountrylist',
        'get_state_list' => 'http://10.12.40.16/index.php/dmlapi/customers/getallregionlist',
        'remove_memo_product' => 'http://10.12.40.16/index.php/dmlapi/inventory/removememoproduct/',
        'remove_invoice_product' => 'http://10.12.40.16/index.php/dmlapi/inventory/removeinvoiceproduct/',
        'regenerate_memo' => 'http://10.12.40.16/index.php/dmlapi/inventory/regeneratememo',
        'regenerate_invoice' => 'http://10.12.40.16/index.php/dmlapi/inventory/regenerateinvoice',
        'get_country_name' => 'http://10.12.40.16/index.php/dmlapi/customer/getcountryname',
        'get_in' => 'In',
        'update_customer_address' => 'http://10.12.40.16/index.php/dmlapi/customers/updatecustomeraddress/',
        'website_url_for_gst_pan_attachment' => 'http://123.108.51.11/upload_customer_doc.php',
        'update_order_address' => 'http://10.12.40.16/index.php/dmlapi/inventory/updateorderaddress/',
      ),
    ),
    'local' => 
    array (
      'create_user' => 'http://127.0.0.1/dealermela/index.php/dmlapi/customers/registercustomerforsoftware/',
      'qrcode_old_image_url_prefix' => 'http://192.168.1.98/dealertest/skin/frontend/default/default/Qrcode/images/',
    ),
    'live' => 
    array (
      'create_user' => 'http://10.22.40.7/index.php/dmlapi/customers/registercustomerforsoftware/',
      'qrcode_old_image_url_prefix' => 'http://diamondmela.com/skin/frontend/default/default/Qrcode/images/',
    ),
    'test' => 
    array (
      'create_user' => 'http://10.12.40.16/index.php/dmlapi/customers/registercustomerforsoftware/',
    ),
    'fixIds' => 
    array (
      'local' => 
      array (
        'customer_entity_varchar_firstname' => '350',
        'customer_entity_varchar_lastname' => '7',
        'quotation_stone_quality_id' => '1240',
        'stone_shape_round' => '36',
        'stone_shape_taper_baguette' => '1596',
        'stone_shape_taper' => '1597',
        'stone_shape_baguette' => '1601',
        'inventory_status_in_id' => '3171',
        'category_ids' => 
        array (
          0 => '14',
          1 => '287',
          2 => '6',
          3 => '7',
          4 => '8',
          5 => '9',
          6 => '124',
          7 => '289',
          8 => '290',
          9 => '195',
          10 => '43',
          11 => '293',
          12 => '165',
          13 => '295',
        ),
      ),
      'live' => 
      array (
        'customer_entity_varchar_firstname' => '350',
        'customer_entity_varchar_lastname' => '7',
        'quotation_stone_quality_id' => '1240',
        'stone_shape_round' => '36',
        'stone_shape_taper_baguette' => '1596',
        'stone_shape_taper' => '1597',
        'stone_shape_baguette' => '1601',
        'inventory_status_in_id' => '3209',
        'category_ids' => 
        array (
          0 => '14',
          1 => '287',
          2 => '6',
          3 => '7',
          4 => '8',
          5 => '9',
          6 => '124',
          7 => '289',
          8 => '290',
          9 => '195',
          10 => '43',
          11 => '293',
          12 => '165',
          13 => '295',
        ),
      ),
    ),
    'fix_labour_charge' => 
    array (
      'ROUND' => '600',
      'FANCY1' => '900',
      'FACNY2' => '900',
    ),
    'approval_type' => 
    array (
      'long_term' => 'Long Term',
      'short_term' => 'Short Term',
    ),
    'deposit_type' => 
    array (
      'deposit' => 'Deposit',
      'without_deposit' => 'Without Deposit',
    ),
    'sales_return_number' => 
    array (
      0 => '1',
    ),
    'invoice_division_number' => 
    array (
      2 => '2',
      3 => '3',
      4 => '4',
    ),
    'invoice_division_limit' => '15000',
    'product' => 
    array (
      'attribute__id' => '41',
    ),
    'product_image_pdf' => 
    array (
      'image_options' => 
      array (
        'with_image' => 'With Image',
        'without_image' => 'Without Image',
      ),
    ),
    'vendor_option' => 
    array (
      'vendor_name' => 'DIAMOND MELA',
    ),
    'pdf_logo' => 
    array (
      'name' => 'Diamond Mela Jewels Ltd',
    ),
    'role' => 
    array (
      'super_admin' => 'Super Admin',
    ),
  ),
  'countrystate' => 
  array (
    'language' => 'eng',
    'limitCountries' => 
    array (
    ),
    'preloadCountryStates' => 
    array (
      0 => 'US',
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'dealertestlive',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'dealertestlive',
        'username' => 'root',
        'password' => 'toor',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => 'dml_',
        'prefix_indexes' => true,
        'strict' => false,
        'engine' => NULL,
        'options' => 
        array (
        ),
        'modes' => 
        array (
          0 => 'STRICT_TRANS_TABLES',
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'dealertestlive',
        'username' => 'root',
        'password' => 'toor',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => 'localhost',
        'port' => '3306',
        'database' => 'dealertestlive',
        'username' => 'root',
        'password' => 'toor',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'options' => 
      array (
        'cluster' => 'predis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
      'cache' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 1,
      ),
    ),
  ),
  'excel' => 
  array (
    'exports' => 
    array (
      'chunk_size' => 1000,
      'pre_calculate_formulas' => false,
      'strict_null_comparison' => false,
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'line_ending' => '
',
        'use_bom' => false,
        'include_separator_line' => false,
        'excel_compatibility' => false,
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'imports' => 
    array (
      'read_only' => true,
      'ignore_empty' => false,
      'heading_row' => 
      array (
        'formatter' => 'slug',
      ),
      'csv' => 
      array (
        'delimiter' => ',',
        'enclosure' => '"',
        'escape_character' => '\\',
        'contiguous' => false,
        'input_encoding' => 'UTF-8',
      ),
      'properties' => 
      array (
        'creator' => '',
        'lastModifiedBy' => '',
        'title' => '',
        'description' => '',
        'subject' => '',
        'keywords' => '',
        'category' => '',
        'manager' => '',
        'company' => '',
      ),
    ),
    'extension_detector' => 
    array (
      'xlsx' => 'Xlsx',
      'xlsm' => 'Xlsx',
      'xltx' => 'Xlsx',
      'xltm' => 'Xlsx',
      'xls' => 'Xls',
      'xlt' => 'Xls',
      'ods' => 'Ods',
      'ots' => 'Ods',
      'slk' => 'Slk',
      'xml' => 'Xml',
      'gnumeric' => 'Gnumeric',
      'htm' => 'Html',
      'html' => 'Html',
      'csv' => 'Csv',
      'tsv' => 'Csv',
      'pdf' => 'Dompdf',
    ),
    'value_binder' => 
    array (
      'default' => 'Maatwebsite\\Excel\\DefaultValueBinder',
    ),
    'cache' => 
    array (
      'enable' => true,
      'driver' => 'memory',
      'settings' => 
      array (
        'memoryCacheSize' => '32MB',
        'cacheTime' => 600,
      ),
      'memcache' => 
      array (
        'host' => 'localhost',
        'port' => 11211,
      ),
      'dir' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\cache',
    ),
    'transactions' => 
    array (
      'handler' => 'db',
    ),
    'temporary_files' => 
    array (
      'local_path' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\framework/laravel-excel',
      'remote_disk' => NULL,
      'remote_prefix' => NULL,
      'force_resync_remote' => NULL,
    ),
    'properties' => 
    array (
      'creator' => 'Maatwebsite',
      'lastModifiedBy' => 'Maatwebsite',
      'title' => 'Spreadsheet',
      'description' => 'Default spreadsheet export',
      'subject' => 'Spreadsheet export',
      'keywords' => 'maatwebsite, excel, export',
      'category' => 'Excel',
      'manager' => 'Maatwebsite',
      'company' => 'Maatwebsite',
    ),
    'sheets' => 
    array (
      'pageSetup' => 
      array (
        'orientation' => 'portrait',
        'paperSize' => '9',
        'scale' => '100',
        'fitToPage' => false,
        'fitToHeight' => true,
        'fitToWidth' => true,
        'columnsToRepeatAtLeft' => 
        array (
          0 => '',
          1 => '',
        ),
        'rowsToRepeatAtTop' => 
        array (
          0 => 0,
          1 => 0,
        ),
        'horizontalCentered' => false,
        'verticalCentered' => false,
        'printArea' => NULL,
        'firstPageNumber' => NULL,
      ),
    ),
    'creator' => 'Maatwebsite',
    'csv' => 
    array (
      'delimiter' => ',',
      'enclosure' => '"',
      'line_ending' => '
',
      'use_bom' => false,
    ),
    'export' => 
    array (
      'autosize' => true,
      'generate_heading_by_indices' => true,
      'merged_cell_alignment' => 'left',
      'calculate' => false,
      'includeCharts' => false,
      'sheets' => 
      array (
        'page_margin' => false,
        'nullValue' => NULL,
        'startCell' => 'A1',
        'strictNullComparison' => false,
      ),
      'store' => 
      array (
        'path' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\exports',
        'returnInfo' => false,
      ),
      'pdf' => 
      array (
        'driver' => 'DomPDF',
        'drivers' => 
        array (
          'DomPDF' => 
          array (
            'path' => 'E:\\xampp\\htdocs\\DML_Development\\vendor/dompdf/dompdf/',
          ),
          'tcPDF' => 
          array (
            'path' => 'E:\\xampp\\htdocs\\DML_Development\\vendor/tecnick.com/tcpdf/',
          ),
          'mPDF' => 
          array (
            'path' => 'E:\\xampp\\htdocs\\DML_Development\\vendor/mpdf/mpdf/',
          ),
        ),
      ),
    ),
    'filters' => 
    array (
      'registered' => 
      array (
        'chunk' => 'Maatwebsite\\Excel\\Filters\\ChunkReadFilter',
      ),
      'enabled' => 
      array (
      ),
    ),
    'import' => 
    array (
      'heading' => 'original',
      'startRow' => 1,
      'separator' => ' ',
      'slug_whitelist' => '._',
      'includeCharts' => false,
      'to_ascii' => true,
      'encoding' => 
      array (
        'input' => 'UTF-8',
        'output' => 'UTF-8',
      ),
      'calculate' => true,
      'ignoreEmpty' => false,
      'force_sheets_collection' => false,
      'dates' => 
      array (
        'enabled' => true,
        'format' => false,
        'columns' => 
        array (
        ),
      ),
      'sheets' => 
      array (
        'test' => 
        array (
          'firstname' => 'A2',
        ),
      ),
    ),
    'views' => 
    array (
      'styles' => 
      array (
        'th' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 12,
          ),
        ),
        'strong' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 12,
          ),
        ),
        'b' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 12,
          ),
        ),
        'i' => 
        array (
          'font' => 
          array (
            'italic' => true,
            'size' => 12,
          ),
        ),
        'h1' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 24,
          ),
        ),
        'h2' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 18,
          ),
        ),
        'h3' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 13.5,
          ),
        ),
        'h4' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 12,
          ),
        ),
        'h5' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 10,
          ),
        ),
        'h6' => 
        array (
          'font' => 
          array (
            'bold' => true,
            'size' => 7.5,
          ),
        ),
        'a' => 
        array (
          'font' => 
          array (
            'underline' => true,
            'color' => 
            array (
              'argb' => 'FF0000FF',
            ),
          ),
        ),
        'hr' => 
        array (
          'borders' => 
          array (
            'bottom' => 
            array (
              'style' => 'thin',
              'color' => 
              array (
                0 => 'FF000000',
              ),
            ),
          ),
        ),
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\app/public',
        'url' => 'http://localhost//storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
      ),
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.mailtrap.io',
    'port' => '2525',
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'encryption' => NULL,
    'username' => NULL,
    'password' => NULL,
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'E:\\xampp\\htdocs\\DML_Development\\resources\\views/vendor/mail',
      ),
    ),
    'log_channel' => NULL,
  ),
  'permission' => 
  array (
    'models' => 
    array (
      'permission' => 'Spatie\\Permission\\Models\\Permission',
      'role' => 'Spatie\\Permission\\Models\\Role',
    ),
    'table_names' => 
    array (
      'roles' => 'roles',
      'permissions' => 'permissions',
      'model_has_permissions' => 'model_has_permissions',
      'model_has_roles' => 'model_has_roles',
      'role_has_permissions' => 'role_has_permissions',
    ),
    'column_names' => 
    array (
      'model_morph_key' => 'model_id',
    ),
    'display_permission_in_exception' => false,
    'cache' => 
    array (
      'expiration_time' => 
      DateInterval::__set_state(array(
         'y' => 0,
         'm' => 0,
         'd' => 0,
         'h' => 24,
         'i' => 0,
         's' => 0,
         'f' => 0.0,
         'weekday' => 0,
         'weekday_behavior' => 0,
         'first_last_day_of' => 0,
         'invert' => 0,
         'days' => false,
         'special_type' => 0,
         'special_amount' => 0,
         'have_weekday_relative' => 0,
         'have_special_relative' => 0,
      )),
      'key' => 'spatie.permission.cache',
      'model_key' => 'name',
      'store' => 'default',
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
      'webhook' => 
      array (
        'secret' => NULL,
        'tolerance' => 300,
      ),
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'E:\\xampp\\htdocs\\DML_Development\\resources\\views',
    ),
    'compiled' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\framework\\views',
  ),
  'dompdf' => 
  array (
    'show_warnings' => false,
    'orientation' => 'portrait',
    'defines' => 
    array (
      'font_dir' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\fonts/',
      'font_cache' => 'E:\\xampp\\htdocs\\DML_Development\\storage\\fonts/',
      'temp_dir' => 'C:\\Users\\rhulkr43\\AppData\\Local\\Temp',
      'chroot' => 'E:\\xampp\\htdocs\\DML_Development',
      'enable_font_subsetting' => false,
      'pdf_backend' => 'CPDF',
      'default_media_type' => 'screen',
      'default_paper_size' => 'a4',
      'default_font' => 'serif',
      'dpi' => 96,
      'enable_php' => false,
      'enable_javascript' => true,
      'enable_remote' => true,
      'font_height_ratio' => 1.1,
      'enable_html5_parser' => false,
    ),
  ),
  'debug-server' => 
  array (
    'host' => 'tcp://127.0.0.1:9912',
  ),
  'charts' => 
  array (
    'default' => 
    array (
      'type' => 'line',
      'library' => 'material',
      'element_label' => 'Element',
      'empty_dataset_label' => 'No Data Set',
      'empty_dataset_value' => 0,
      'title' => 'My Cool Chart',
      'height' => 400,
      'width' => 0,
      'responsive' => false,
      'background_color' => 'inherit',
      'colors' => 
      array (
      ),
      'one_color' => false,
      'template' => 'material',
      'legend' => true,
      'x_axis_title' => false,
      'y_axis_title' => NULL,
      'loader' => 
      array (
        'active' => true,
        'duration' => 500,
        'color' => '#000000',
      ),
    ),
    'templates' => 
    array (
      'material' => 
      array (
        0 => '#2196F3',
        1 => '#F44336',
        2 => '#FFC107',
      ),
      'red-material' => 
      array (
        0 => '#B71C1C',
        1 => '#F44336',
        2 => '#E57373',
      ),
      'indigo-material' => 
      array (
        0 => '#1A237E',
        1 => '#3F51B5',
        2 => '#7986CB',
      ),
      'blue-material' => 
      array (
        0 => '#0D47A1',
        1 => '#2196F3',
        2 => '#64B5F6',
      ),
      'teal-material' => 
      array (
        0 => '#004D40',
        1 => '#009688',
        2 => '#4DB6AC',
      ),
      'green-material' => 
      array (
        0 => '#1B5E20',
        1 => '#4CAF50',
        2 => '#81C784',
      ),
      'yellow-material' => 
      array (
        0 => '#F57F17',
        1 => '#FFEB3B',
        2 => '#FFF176',
      ),
      'orange-material' => 
      array (
        0 => '#E65100',
        1 => '#FF9800',
        2 => '#FFB74D',
      ),
    ),
    'assets' => 
    array (
      'global' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js',
        ),
      ),
      'canvas-gauges' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdn.rawgit.com/Mikhus/canvas-gauges/gh-pages/download/2.1.2/all/gauge.min.js',
        ),
      ),
      'chartist' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/chartist/0.10.1/chartist.min.js',
        ),
        'styles' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/chartist/0.10.1/chartist.min.css',
        ),
      ),
      'chartjs' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js',
        ),
      ),
      'fusioncharts' => 
      array (
        'scripts' => 
        array (
          0 => 'https://static.fusioncharts.com/code/latest/fusioncharts.js',
          1 => 'https://static.fusioncharts.com/code/latest/themes/fusioncharts.theme.fint.js',
        ),
      ),
      'google' => 
      array (
        'scripts' => 
        array (
          0 => 'https://www.google.com/jsapi',
          1 => 'https://www.gstatic.com/charts/loader.js',
          2 => 'google.charts.load(\'current\', {\'packages\':[\'corechart\', \'gauge\', \'geochart\', \'bar\', \'line\']})',
        ),
      ),
      'highcharts' => 
      array (
        'styles' => 
        array (
        ),
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/highcharts/5.0.7/highcharts.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/highcharts/5.0.7/js/modules/offline-exporting.js',
          2 => 'https://cdnjs.cloudflare.com/ajax/libs/highmaps/5.0.7/js/modules/map.js',
          3 => 'https://cdnjs.cloudflare.com/ajax/libs/highmaps/5.0.7/js/modules/data.js',
          4 => 'https://code.highcharts.com/mapdata/custom/world.js',
        ),
      ),
      'justgage' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/raphael/2.2.6/raphael.min.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/justgage/1.2.2/justgage.min.js',
        ),
      ),
      'morris' => 
      array (
        'styles' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css',
        ),
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/raphael/2.2.6/raphael.min.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js',
        ),
      ),
      'plottablejs' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/plottable.js/2.8.0/plottable.min.js',
        ),
        'styles' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/plottable.js/2.2.0/plottable.css',
        ),
      ),
      'progressbarjs' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/progressbar.js/1.0.1/progressbar.min.js',
        ),
      ),
      'c3' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.js',
        ),
        'styles' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.css',
        ),
      ),
      'echarts' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/echarts/3.6.2/echarts.min.js',
        ),
      ),
      'amcharts' => 
      array (
        'scripts' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/amcharts.js',
          1 => 'https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/serial.js',
          2 => 'https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/plugins/export/export.min.js',
          3 => 'https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/themes/light.js',
        ),
        'styles' => 
        array (
          0 => 'https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/plugins/export/export.css',
        ),
      ),
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
